#ifndef ZZ_CODEGEN_INCLUDE
#define ZZ_CODEGEN_INCLUDE


#define PPF_PATH "..\..\lib"

#include "ds.def/general.h"



// -----------------------------------------------
// -----------------------------------------------



#endif // ZZ_CODEGEN_INCLUDE
