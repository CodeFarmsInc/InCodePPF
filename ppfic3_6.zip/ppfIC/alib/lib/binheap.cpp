// Empty file -- all functions are inherited from the Array.
// Reason: The original array class in DOL included several optional
// uses which now are divided into three classes:
//     Array, Stack, and BinaryHeap.
