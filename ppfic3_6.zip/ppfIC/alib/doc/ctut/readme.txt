This directory is the verification of test1 used in the C++ tutorial.

tt1.bat compiles test1.cpp
rr1.bat runs test1
jj1.bat generates the UML class diagram for test1 using Java
ss1.bat generates the SVG file of the UML diagram which can be
        displayed with any Interent browser.

