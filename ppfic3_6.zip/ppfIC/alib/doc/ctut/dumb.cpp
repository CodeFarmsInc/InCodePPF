#include "gen.h"
    class Manager : public Employee {
