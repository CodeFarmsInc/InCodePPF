#ifndef ZZ_CODEGEN_INCLUDE
#define ZZ_CODEGEN_INCLUDE

#include "ds.def/general.h"



// -----------------------------------------------
#ifdef ZZmain

#else // ZZmain
#endif // ZZmain
// -----------------------------------------------



#endif // ZZ_CODEGEN_INCLUDE
