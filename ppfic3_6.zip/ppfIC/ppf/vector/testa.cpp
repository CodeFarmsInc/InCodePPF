#include "testA.h"

PersistImplement(A); // use just once, typically in A.cpp
