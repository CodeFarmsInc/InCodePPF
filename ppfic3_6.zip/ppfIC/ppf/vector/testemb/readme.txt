This is an unsuccessful attempt to build an array of PersistPtr<A>
without an intermediary class. Whatever I do, it does not compile,
and the code is too tricky for real-life purposes.

tte.bat compiles the test, 
re1.bat re2.bat re3.bat run consecutive tests.

    Jiri Soukup, June 28, 2012
