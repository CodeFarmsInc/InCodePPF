#include "test1a.h" // must be used because PersistPtr<A> is used in class B
#include "test1b.h"

PersistImplement(B); // use just once, typically in b.cpp

// implementation of methods for class B
void B::prt(PersistPtr<B> pb,char *txtEnd){
      pb.prt("pb=","");
      next.prt("next=","");
      aPtr.prt("aPtr=","");
      arr.prt("aPtr=",txtEnd);
      cout.flush(); 
}
