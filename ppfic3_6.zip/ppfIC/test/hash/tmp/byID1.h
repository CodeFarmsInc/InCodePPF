// CONVERTED TO PPF
// +++++++++++++++++

// -------- data structure HASH TABLE ---------------
// EQUIVALENT OF:
// template <class Holder,class Element> class byID_Hash 
// ----------------------------------------------------------
#ifndef ZZ_byID_HASH1_INCLUDED
#define ZZ_byID_HASH1_INCLUDED

class Company;
class Employee;

// ----------------------------------------------------------
// description of the cooperating classes
// ----------------------------------------------------------
class byID_HashHolder : public byID_ArrayHolder {
public:
    int count; // population count
    byID_HashHolder() : byID_ArrayHolder(){count=0;}
};

class byID_HashElement {
public:
    PTR(Employee) next; // ring of elements in the same bucket
    byID_HashElement(){next=NULL;}
};

class byID_HashLink {
    PersistClass(byID_HashLink);
    friend class byID_Hash;
    PTR(Employee) lnk;
};

class byID_Hash : public byID_Array {
public:
    static PTR(PersistVoid) form(PTR(Company) hp,int const sz);
    static int formed(PTR(Company) hp){ return byID_Array::formed(hp); }
    static int size(PTR(Company) hp, int *popCount);
    static void free(PTR(Company) hp);
    static int resize(PTR(Company) hp, int newSz);
    static PTR(Employee) get(PTR(Company) hp, PTR(Employee) obj); // obj = temp.object with the required key
    static int add(PTR(Company) hp, PTR(Employee) obj); // obj = object to load into the hash table
    static PTR(Employee) remove(PTR(Company) hp, PTR(Employee) obj); 
            // obj = object with the key to be removed or the object itself

    // functions that must be provided by the application
    // --------------------------------------------------
    static int cmp(PTR(Employee) p1,PTR(Employee) p2); // return 0 if the objects have the same key
    static int hash(PTR(Employee) p,int hashSz); // converts key to the bucket number

    // convenient functions to use when coding hash()
    // --------------------------------------------------
    static int hashString(char *s,int hashSz);
    static int hashInt(int val,int hashSz);

    // historical DOL interface
    // --------------------------------------------------
    static PTR(Employee) del(PTR(Company) hp, PTR(Employee) obj){return remove(hp,obj);}
    static PTR(Employee) slot(PTR(Company) hp, int i);
    static int ZZhashString(char *s,int hashSz){return hashString(s,hashSz);}
    static int ZZhashInt(int val,int hashSz){return hashInt(val,hashSz);}
};


class byID_HashIterator {
    int all; // 1=all buckets, 0=just one given bucket
    int bucket;
    PTR(Employee) tail;
    PTR(Employee) nxt;
    PTR(Company) holder;
public:
    byID_HashIterator(){all=0; bucket= -1; nxt=NULL; holder=NULL;}

    // standard iterator interface:   for(p=it.first(hp,i); p; p=it.next()){...}
    // -----------------------------------------------------------------
    PTR(Employee) first(PTR(Company) hp,int i);  // traverse bucket i, for i<0 traverse all buckets
    PTR(Employee) const next();

    // historical DOL iterator:  it.start(x); for(p= ++it; p; p= ++it){...}
    // -----------------------------------------------------------------
    void start(PTR(Employee) p){tail=p; nxt=NULL; all=bucket=0; holder=NULL;}
    PTR(Employee) const operator++();
    byID_HashIterator(PTR(Employee) p){start(p);}
};

#endif // ZZ_byID_HASH1_INCLUDED
