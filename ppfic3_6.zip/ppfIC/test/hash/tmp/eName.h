#ifndef ZZ_eName_NAME_INCLUDED
#define ZZ_eName_NAME_INCLUDED
#include PPF_PATH

// -------- data structure SINGLY LINKED LIST ---------------
// EQUIVALENT OF:
// template <class Parent> class eName_Name {
// ----------------------------------------------------------

class Employee;

// description of the cooperating classes
class eName_NameParent {
public:
    PersistString name;
    eName_NameParent(){ name=NULL; }
};

// ----------------------------------------------------------

class eName_Name {

public:
    static void add(PTR(Employee) p, STR c);     // add link to
    static void addNew(PTR(Employee) p, char *c);  // allocate string, add link
    static STR  get(PTR(Employee) p);
    static void  remove(PTR(Employee) p);
    static int compare(PTR(Employee) p1,PTR(Employee) p2);
    // ...
    // historical DOL interface
    static STR  del(PTR(Employee) p){STR  s=get(p); remove(p); return s;}
    static STR  fwd(PTR(Employee) p){return get(p);}
};
    
#endif // ZZ_eName_NAME_INCLUDED
