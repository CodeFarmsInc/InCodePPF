
// -------- data structure SINGLY LINKED LIST ---------------
// EQUIVALENT OF:
// template <class Parent,class Child> class eList_LinkedList
// ----------------------------------------------------------
#ifndef ZZ_eList_LINKED_LIST1_INCLUDED
#define ZZ_eList_LINKED_LIST1_INCLUDED

class Company;
class Employee;

// ----------------------------------------------------------
// description of the cooperating classes
// ----------------------------------------------------------
class eList_LinkedList1Parent {
public:
    PTR(Employee) tail;
    eList_LinkedList1Parent(){ tail=NULL; }
};

class eList_LinkedList1Child : public eList_Ring1Element {
public:
    eList_LinkedList1Child() : eList_Ring1Element(){ }
};

// the following class is used when Parent==Child
class eList_LinkedList1ParentLinkedList1Child : public eList_Ring1Element {
public:
    PTR(Employee) tail;
    eList_LinkedList1ParentLinkedList1Child() : eList_Ring1Element(){ tail=NULL; }
};
// ----------------------------------------------------------

class eList_LinkedList1 : eList_Ring1 {

public:
    static PTR(Employee) tail(PTR(Company) p);
    static PTR(Employee) head(PTR(Company) p);
    static void addHead(PTR(Company) p, PTR(Employee) c);
    static void addTail(PTR(Company) p, PTR(Employee) c);
    static void append(PTR(Company) p,PTR(Employee) c1, PTR(Employee) c2);
    static void remove(PTR(Company) p, PTR(Employee) c);
    static PTR(Employee) const next(PTR(Company) p,PTR(Employee) c);
    static PTR(Employee) const nextRing(PTR(Employee) c);
    static void sort(eList_sortFun cmpFun, PTR(Company) p);
    static void merge(PTR(Employee) s,PTR(Employee) t,PTR(Company) p);
    static void setTail(PTR(Company) p,PTR(Employee) c,int check);

    // historical DOL compatible interface
    static void del(PTR(Company) p, PTR(Employee) c){ remove(p,c);}
    static void add(PTR(Company) p, PTR(Employee) c){ addHead(p,c);}
    static PTR(Employee) child(PTR(Company) p);
    static void set(PTR(Company) p,PTR(Employee) c){ setTail(p,c,0);}
    static PTR(Employee) const fwd(PTR(Employee) c){ return nextRing(c);}
};

class eList_LinkedList1Iterator : public eList_Ring1Iterator {
public:
    eList_LinkedList1Iterator() : eList_Ring1Iterator(){}
    eList_LinkedList1Iterator(const PTR(Company) p) : eList_Ring1Iterator(){start(p);}
    void start(const PTR(Company) p);
    PTR(Employee) fromHead(PTR(Company) p);
};
    
#endif // ZZ_eList_LINKED_LIST1_INCLUDED
