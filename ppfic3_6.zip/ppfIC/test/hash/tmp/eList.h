

// -------- data structure SINGLY LINKED RING ---------------
// EQUIVALENT OF:
// template <class Node> class eList_Ring1
// ----------------------------------------------------------
#ifndef ZZ_eList_RING1_INCLUDED
#define ZZ_eList_RING1_INCLUDED

#include "environ.h"
#include PPF_PATH

class Employee;
typedef int (*eList_sortFun)(const PTR(Employee), const PTR(Employee));

// ----------------------------------------------------------
// description of the cooperating classes
// ----------------------------------------------------------
class eList_Ring1Element {
public:
    PTR(Employee) next;
    eList_Ring1Element(){ next=NULL; }
};

class eList_Ring1 {

public:
    // standard interface
    static PTR(Employee) addHead(PTR(Employee) tail, PTR(Employee) c); // returns new tail
    static PTR(Employee) addTail(PTR(Employee) tail, PTR(Employee) c); // returns new tail
    static PTR(Employee) append(PTR(Employee) tail,PTR(Employee) c1, PTR(Employee) c2); // returns new tail
    static PTR(Employee) remove(PTR(Employee) tail, PTR(Employee) c);  // returns new tail, NULL when empty
    static PTR(Employee) const next(PTR(Employee) p, PTR(Employee) c); // returns NULL when p is tail
    static PTR(Employee) const nextRing(PTR(Employee) c); // unprotected raw ring pointer
    static PTR(Employee) sort(eList_sortFun cmpFun, PTR(Employee) tail); // returns the new tail
    static void merge(PTR(Employee) s,PTR(Employee) t);

    // historical DOL compatible interface
    static PTR(Employee) del(PTR(Employee) tail, PTR(Employee) c) { return remove(tail,c); }
    static PTR(Employee) add(PTR(Employee) tail, PTR(Employee) c) { return addHead(tail,c); }
    static PTR(Employee) const fwd(PTR(Employee) c){ return nextRing(c);}
};

class eList_Ring1Iterator {
    PTR(Employee) tail; // NULL when loop finished
    PTR(Employee) nxt;  // NULL when starting a new loop
public:
    // standard interface:          for(p=it.fromHead(x); p; p=it.next()){...}
    eList_Ring1Iterator(){tail=nxt=NULL;}
    PTR(Employee) fromHead(PTR(Employee) p);
    PTR(Employee) const next();

    // historical DOL interface:    it.start(x); for(p= ++it; p; p= ++it){...}
    void start(PTR(Employee) p);
    PTR(Employee) const operator++();
    eList_Ring1Iterator(Employee *p){start(p);}
};
    
#endif // ZZ_eList_RING1_INCLUDED
