#include <string.h>

class Employee;

void eName_Name::add(PTR(Employee) p, STR c){
    STR s=p->ZZds.ZZeName.name;
    if(s!=NULL){
        printf("eName:add() error: object=%d has already a name\n",p); return;
    }
    p->ZZds.ZZeName.name=c;
}

void eName_Name::addNew(PTR(Employee) p, char *c){
    if(c==NULL){
        printf("eName:addNew() given a NULL name\n"); return;
    }
    p->ZZds.ZZeName.name=new PersistString(c);
}

void eName_Name::remove(PTR(Employee) p1){
    if(p1->ZZds.ZZeName.name==NULL)return; (p1->ZZds.ZZeName.name).delString(); p1->ZZds.ZZeName.name=NULL; }

STR eName_Name::get(PTR(Employee) p){ return p->ZZds.ZZeName.name;}

int eName_Name::compare(PTR(Employee) p1, PTR(Employee) p2){
    return strcmp((p1->ZZds.ZZeName.name).getPtr(), (p2->ZZds.ZZeName.name).getPtr());
}

