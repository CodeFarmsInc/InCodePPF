===========================================================================
Use the test in the 'bench' directory if some parameters or directory
references seem broken.
This is the benchmark from the book, and it is the largest, most comprehensive
test we tried.
===========================================================================
clean.bat cleans all the data, *.obj, *.exe, and results files for all tests
regr.bat runs a complete regression sequence (all the tests)
check.bat checks the results of all the tests
