class BookToAuthor;
class Book;
                          
// Implementation taken over from Aggregate2, except for
// the changed order of parameters -- see the inline methods
