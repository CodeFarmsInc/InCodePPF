
// -------- data structure SINGLY LINKED LIST ---------------
// EQUIVALENT OF:
// template <class Parent,class Child> class students_LinkedList
// ----------------------------------------------------------
#ifndef ZZ_students_LINKED_LIST1_INCLUDED
#define ZZ_students_LINKED_LIST1_INCLUDED

class Faculty;
class Student;

// ----------------------------------------------------------
// description of the cooperating classes
// ----------------------------------------------------------
class students_LinkedList1Parent {
public:
    PTR(Student) tail;
    students_LinkedList1Parent(){ tail=NULL; }
};

class students_LinkedList1Child : public students_Ring1Element {
public:
    students_LinkedList1Child() : students_Ring1Element(){ }
};

// the following class is used when Parent==Child
class students_LinkedList1ParentLinkedList1Child : public students_Ring1Element {
public:
    PTR(Student) tail;
    students_LinkedList1ParentLinkedList1Child() : students_Ring1Element(){ tail=NULL; }
};
// ----------------------------------------------------------

class students_LinkedList1 : students_Ring1 {

public:
    static PTR(Student) tail(PTR(Faculty) p);
    static PTR(Student) head(PTR(Faculty) p);
    static void addHead(PTR(Faculty) p, PTR(Student) c);
    static void addTail(PTR(Faculty) p, PTR(Student) c);
    static void append(PTR(Faculty) p,PTR(Student) c1, PTR(Student) c2);
    static void remove(PTR(Faculty) p, PTR(Student) c);
    static PTR(Student) const next(PTR(Faculty) p,PTR(Student) c);
    static PTR(Student) const nextRing(PTR(Student) c);
    static void sort(students_sortFun cmpFun, PTR(Faculty) p);
    static void merge(PTR(Student) s,PTR(Student) t,PTR(Faculty) p);
    static void setTail(PTR(Faculty) p,PTR(Student) c,int check);

    // historical DOL compatible interface
    static void del(PTR(Faculty) p, PTR(Student) c){ remove(p,c);}
    static void add(PTR(Faculty) p, PTR(Student) c){ addHead(p,c);}
    static PTR(Student) child(PTR(Faculty) p);
    static void set(PTR(Faculty) p,PTR(Student) c){ setTail(p,c,0);}
    static PTR(Student) const fwd(PTR(Student) c){ return nextRing(c);}
};

class students_LinkedList1Iterator : public students_Ring1Iterator {
public:
    students_LinkedList1Iterator() : students_Ring1Iterator(){}
    students_LinkedList1Iterator(const PTR(Faculty) p) : students_Ring1Iterator(){start(p);}
    void start(const PTR(Faculty) p);
    PTR(Student) fromHead(PTR(Faculty) p);
};
    
#endif // ZZ_students_LINKED_LIST1_INCLUDED
