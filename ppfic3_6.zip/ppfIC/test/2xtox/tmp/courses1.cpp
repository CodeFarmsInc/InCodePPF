
// --------------------------------------------------------
class Faculty;
class Course;

PTR(Course) courses_LinkedList1::tail(PTR(Faculty) p){return p->ZZds.ZZcourses.tail;}

PTR(Course) courses_LinkedList1::head(PTR(Faculty) p){
    if(!(p->ZZds.ZZcourses.tail) || !(p->ZZds.ZZcourses.tail->ZZds.ZZcourses.next))return NULL;
    else return p->ZZds.ZZcourses.tail->ZZds.ZZcourses.next;
}

void courses_LinkedList1::addHead(PTR(Faculty) p, PTR(Course) c){
    p->ZZds.ZZcourses.tail=courses_Ring1::addHead(p->ZZds.ZZcourses.tail,c);
}

void courses_LinkedList1::addTail(PTR(Faculty) p, PTR(Course) c){
    p->ZZds.ZZcourses.tail=courses_Ring1::addTail(p->ZZds.ZZcourses.tail,c);
}

void courses_LinkedList1::append(PTR(Faculty) p,PTR(Course) c1, PTR(Course) c2){
    p->ZZds.ZZcourses.tail=courses_Ring1::append(p->ZZds.ZZcourses.tail,c1,c2);
}

void courses_LinkedList1::remove(PTR(Faculty) p, PTR(Course) c){
    p->ZZds.ZZcourses.tail=courses_Ring1::remove(p->ZZds.ZZcourses.tail,c);
}

PTR(Course) const courses_LinkedList1::next(PTR(Faculty) p,PTR(Course) c){
    return courses_Ring1::next(p->ZZds.ZZcourses.tail,c);
}

PTR(Course) const courses_LinkedList1::nextRing(PTR(Course) c){ return courses_Ring1::nextRing(c);}

void courses_LinkedList1::sort(courses_sortFun cmpFun, PTR(Faculty) p){
    p->ZZds.ZZcourses.tail=courses_Ring1::sort(cmpFun,p->ZZds.ZZcourses.tail);
}

// ---------------------------------------------------------------
// This function either merges two lists (if s and t are on different lists)
// or splits a list (if s and t are on the same list).
//
// When merging lists, p must be a parent of t, and will be set p->tail=NULL.
// When splitting a list, p must be an empty list holder (p->tail==NULL)
// and will be set p->tail=t.
// ---------------------------------------------------------------
void courses_LinkedList1::merge(PTR(Course) s,PTR(Course) t,PTR(Faculty) p){
    PTR(Course) pp,tail; int merge;
 
    tail=p->ZZds.ZZcourses.tail;
    if(tail==NULL)merge=0; else merge=1; // 0=splitting
    if(merge){
        // check that t is child of p
        for(pp=t->ZZds.ZZcourses.next; pp; pp=pp->ZZds.ZZcourses.next){
            if(pp==tail)break;
            if(pp==t)pp=NULL;
        }
        if(!pp){
            printf("courses error in merge(): merging, inconsistent input\n    ");
            printf("p is not the parent of t\n");
        }
    }
    else {
        // check that s and t are on the same list
        for(pp=s->ZZds.ZZcourses.next; pp; pp=pp->ZZds.ZZcourses.next){
            if(pp==t)break;
            if(pp==s)pp=NULL;
        }
        if(!pp){
            printf("courses error in merge(): splitting, inconsistent input\n    ");
            printf("p has not children but s and t are not in the same list\n");
        }
    }
    
    courses_Ring1::merge(s,t); 
    if(merge)p->ZZds.ZZcourses.tail=NULL; else p->ZZds.ZZcourses.tail=t;
}

PTR(Course) courses_LinkedList1::child(PTR(Faculty) p){
    PTR(Course) t;
    t=p->ZZds.ZZcourses.tail; if(t)return t->ZZds.ZZcourses.next; return NULL;
}

// ------------------------------------------------------------------
// check=1 checks for consistency,
// check=0 is fast but a mistake can cause a hard-to-find error
// ------------------------------------------------------------------
void courses_LinkedList1::setTail(PTR(Faculty) p,PTR(Course) c,int check){
    PTR(Course) pp,tail;

    tail=p->ZZds.ZZcourses.tail; 
    if(check && tail){
        for(pp=tail->ZZds.ZZcourses.next; pp; pp=pp->ZZds.ZZcourses.next){
            if(pp==c || pp==tail)break;
        }
        if(pp!=c){
            printf("courses warning: setTail() for a wrong set of children,");
            printf(" nothing done\n");
            return;
        }
    }
    p->ZZds.ZZcourses.tail=c;
}

void courses_LinkedList1Iterator::start(const PTR(Faculty) p){
    courses_Ring1Iterator::start(p->ZZds.ZZcourses.tail); 
}

PTR(Course) courses_LinkedList1Iterator::fromHead(PTR(Faculty) p){
    return courses_Ring1Iterator::fromHead(p->ZZds.ZZcourses.tail); 
}
