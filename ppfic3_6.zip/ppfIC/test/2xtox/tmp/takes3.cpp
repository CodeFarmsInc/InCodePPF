class Takes;
class Student;
                          
// Implementation taken over from Aggregate2, except for
// the changed order of parameters -- see the inline methods
