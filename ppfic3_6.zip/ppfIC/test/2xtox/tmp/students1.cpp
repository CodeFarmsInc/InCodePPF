
// --------------------------------------------------------
class Faculty;
class Student;

PTR(Student) students_LinkedList1::tail(PTR(Faculty) p){return p->ZZds.ZZstudents.tail;}

PTR(Student) students_LinkedList1::head(PTR(Faculty) p){
    if(!(p->ZZds.ZZstudents.tail) || !(p->ZZds.ZZstudents.tail->ZZds.ZZstudents.next))return NULL;
    else return p->ZZds.ZZstudents.tail->ZZds.ZZstudents.next;
}

void students_LinkedList1::addHead(PTR(Faculty) p, PTR(Student) c){
    p->ZZds.ZZstudents.tail=students_Ring1::addHead(p->ZZds.ZZstudents.tail,c);
}

void students_LinkedList1::addTail(PTR(Faculty) p, PTR(Student) c){
    p->ZZds.ZZstudents.tail=students_Ring1::addTail(p->ZZds.ZZstudents.tail,c);
}

void students_LinkedList1::append(PTR(Faculty) p,PTR(Student) c1, PTR(Student) c2){
    p->ZZds.ZZstudents.tail=students_Ring1::append(p->ZZds.ZZstudents.tail,c1,c2);
}

void students_LinkedList1::remove(PTR(Faculty) p, PTR(Student) c){
    p->ZZds.ZZstudents.tail=students_Ring1::remove(p->ZZds.ZZstudents.tail,c);
}

PTR(Student) const students_LinkedList1::next(PTR(Faculty) p,PTR(Student) c){
    return students_Ring1::next(p->ZZds.ZZstudents.tail,c);
}

PTR(Student) const students_LinkedList1::nextRing(PTR(Student) c){ return students_Ring1::nextRing(c);}

void students_LinkedList1::sort(students_sortFun cmpFun, PTR(Faculty) p){
    p->ZZds.ZZstudents.tail=students_Ring1::sort(cmpFun,p->ZZds.ZZstudents.tail);
}

// ---------------------------------------------------------------
// This function either merges two lists (if s and t are on different lists)
// or splits a list (if s and t are on the same list).
//
// When merging lists, p must be a parent of t, and will be set p->tail=NULL.
// When splitting a list, p must be an empty list holder (p->tail==NULL)
// and will be set p->tail=t.
// ---------------------------------------------------------------
void students_LinkedList1::merge(PTR(Student) s,PTR(Student) t,PTR(Faculty) p){
    PTR(Student) pp,tail; int merge;
 
    tail=p->ZZds.ZZstudents.tail;
    if(tail==NULL)merge=0; else merge=1; // 0=splitting
    if(merge){
        // check that t is child of p
        for(pp=t->ZZds.ZZstudents.next; pp; pp=pp->ZZds.ZZstudents.next){
            if(pp==tail)break;
            if(pp==t)pp=NULL;
        }
        if(!pp){
            printf("students error in merge(): merging, inconsistent input\n    ");
            printf("p is not the parent of t\n");
        }
    }
    else {
        // check that s and t are on the same list
        for(pp=s->ZZds.ZZstudents.next; pp; pp=pp->ZZds.ZZstudents.next){
            if(pp==t)break;
            if(pp==s)pp=NULL;
        }
        if(!pp){
            printf("students error in merge(): splitting, inconsistent input\n    ");
            printf("p has not children but s and t are not in the same list\n");
        }
    }
    
    students_Ring1::merge(s,t); 
    if(merge)p->ZZds.ZZstudents.tail=NULL; else p->ZZds.ZZstudents.tail=t;
}

PTR(Student) students_LinkedList1::child(PTR(Faculty) p){
    PTR(Student) t;
    t=p->ZZds.ZZstudents.tail; if(t)return t->ZZds.ZZstudents.next; return NULL;
}

// ------------------------------------------------------------------
// check=1 checks for consistency,
// check=0 is fast but a mistake can cause a hard-to-find error
// ------------------------------------------------------------------
void students_LinkedList1::setTail(PTR(Faculty) p,PTR(Student) c,int check){
    PTR(Student) pp,tail;

    tail=p->ZZds.ZZstudents.tail; 
    if(check && tail){
        for(pp=tail->ZZds.ZZstudents.next; pp; pp=pp->ZZds.ZZstudents.next){
            if(pp==c || pp==tail)break;
        }
        if(pp!=c){
            printf("students warning: setTail() for a wrong set of children,");
            printf(" nothing done\n");
            return;
        }
    }
    p->ZZds.ZZstudents.tail=c;
}

void students_LinkedList1Iterator::start(const PTR(Faculty) p){
    students_Ring1Iterator::start(p->ZZds.ZZstudents.tail); 
}

PTR(Student) students_LinkedList1Iterator::fromHead(PTR(Faculty) p){
    return students_Ring1Iterator::fromHead(p->ZZds.ZZstudents.tail); 
}
