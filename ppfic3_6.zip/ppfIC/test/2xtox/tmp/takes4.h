// ----------------------------------------------------------
//                    2XtoX<Relation,Entity1,Entity2>
//
// This is the most frequently used Many-To-Many relation between
// two entity types. For each recorded relation there is on Relation object.
// ----------------------------------------------------------
// By repeating this code with minor modifications, it is easy
// to derive higher order many-to-many relations:
//    from 2XtoX to derive 2XtoX (this code)
//    from 2XtoX to derive 3XtoX
//    from 3XtoX to derive 4XtoX
//    ... and so on ...
//                                    Jiri Soukup, July 14, 2005
// ----------------------------------------------------------

// ----------------------------------------------------------
#ifndef ZZ_takes_2XTOX_INCLUDED
#define ZZ_takes_2XTOX_INCLUDED

class Takes;
class Student;
class Course;

// description of the cooperating classes
class takes_2XtoXRelation : public takes_1XtoXRelation {
public:
    PTR(Takes) next2;
    PTR(Takes) prev2;
    PTR(Course) parent2;
    takes_2XtoXRelation() : takes_1XtoXRelation(){ next2=prev2=NULL; parent2=NULL;}
};

class takes_2XtoXEntity1 : public takes_1XtoXEntity1 {
public:
    takes_2XtoXEntity1() : takes_1XtoXEntity1(){ }
};

class takes_2XtoXEntity2 {
public:
    PTR(Takes) tail2;
    takes_2XtoXEntity2(){tail2=NULL;}
};


// ----------------------------------------------------------

class takes_2XtoX : public takes_1XtoX {

public:
    static void add(PTR(Takes) r, PTR(Student) e1,PTR(Course) e2); // equivalent of addTail()
    static void remove(PTR(Takes) r);

    static PTR(Student) const entity1(PTR(Takes) r){return takes_1XtoX::entity1(r);}
    static PTR(Takes) const next1(PTR(Takes) r)  {return takes_1XtoX::next1(r);}
    static PTR(Takes) const prev1(PTR(Takes) r)  {return takes_1XtoX::prev1(r);}

    static PTR(Course) const entity2(PTR(Takes) r);
    static PTR(Takes) const next2(PTR(Takes) r);   // returns NULL when s is the tail
    static PTR(Takes) const prev2(PTR(Takes) r);   // returns NULL when s is the head
};

class takes_2XtoXIterator : public takes_1XtoXIterator {
    // standard interface:          for(r=it.from1(e1); r; r=it.next1()){...}
    // standard interface:          for(r=it.from2(e2); r; r=it.next2()){...}
    PTR(Takes) tail2;
    PTR(Takes) nxt2;
public:
    PTR(Takes) from1(PTR(Student) e) {return takes_1XtoXIterator::from1(e);}
    PTR(Takes) const next1(){return takes_1XtoXIterator::next1();}

    PTR(Takes) from2(PTR(Course) e);
    PTR(Takes) const next2();
};

#endif // ZZ_takes_2XTOX_INCLUDED
