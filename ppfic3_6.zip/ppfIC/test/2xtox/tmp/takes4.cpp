// THIS FILE HAS NOT BEEN CONVERTED AND MAY NOT BE NEEDED
// If we do need it, than it should be renamed mton.cpp
// -------------------------------------------------------------
class Takes; // relation
class Student; // entity1
class Course; // entity2
                          
void takes_2XtoX::add(PTR(Takes) r,PTR(Student) e1,PTR(Course) e2){ // equivalent of addTail()
    PTR(Takes) head;

    takes_1XtoX::add(r,e1);

    if(r->ZZds.ZZtakes.next2){
        printf("takes.add() error: element=%d already in takes\n",r);
        return;
    }
    if(e2->ZZds.ZZtakes.tail2){
        head=e2->ZZds.ZZtakes.tail2->ZZds.ZZtakes.next2;
        r->ZZds.ZZtakes.next2=head; e2->ZZds.ZZtakes.tail2->ZZds.ZZtakes.next2=r;
        r->ZZds.ZZtakes.prev2=e2->ZZds.ZZtakes.tail2; head->ZZds.ZZtakes.prev2=r;
    }
    else {e2->ZZds.ZZtakes.tail2=r->ZZds.ZZtakes.next2=r->ZZds.ZZtakes.prev2=r;}

    e2->ZZds.ZZtakes.tail2=r;
    r->ZZds.ZZtakes.parent2=e2;
}

void takes_2XtoX::remove(PTR(Takes) r){
    PTR(Takes) prv,nxt; PTR(Course) par;

    takes_1XtoX::remove(r);

    nxt=r->ZZds.ZZtakes.next2;
    prv=r->ZZds.ZZtakes.prev2;
    par=r->ZZds.ZZtakes.parent2;
    if(nxt==NULL || prv==NULL || par==NULL){
        printf("takes:remove() error: node=%d not on the list\n",r); return;
    }

    if(r==nxt)par->ZZds.ZZtakes.tail2=NULL;
    else {
        if(r==par->ZZds.ZZtakes.tail2)par->ZZds.ZZtakes.tail2=prv;
        prv->ZZds.ZZtakes.next2=nxt;
        nxt->ZZds.ZZtakes.prev2=prv;
    }
    r->ZZds.ZZtakes.next2=r->ZZds.ZZtakes.prev2=NULL;
    r->ZZds.ZZtakes.parent2=NULL;
}

PTR(Course) const takes_2XtoX::entity2(PTR(Takes) r){return r->ZZds.ZZtakes.parent2;}

PTR(Takes) const takes_2XtoX::next2(PTR(Takes) r){   // returns NULL when s is the tail
    PTR(Course) p2;
    p2=r->ZZds.ZZtakes.parent2;
    if(!r || !p2)return NULL;
    if(r==p2->ZZds.ZZtakes.tail2)return NULL;
    return r->ZZds.ZZtakes.next2;
}
    

PTR(Takes) const takes_2XtoX::prev2(PTR(Takes) r){   // returns NULL when s is the head
    PTR(Course) p2; PTR(Takes) prv;
    p2=r->ZZds.ZZtakes.parent2;
    if(!r || !p2)return NULL;
    prv=r->ZZds.ZZtakes.prev2;
    if(prv==p2->ZZds.ZZtakes.tail2)return NULL;
    return prv;
}

PTR(Takes) takes_2XtoXIterator::from2(PTR(Course) e){
    PTR(Takes) ret;

    tail2=e->ZZds.ZZtakes.tail2;
    if(!tail2)return NULL;
    ret=tail2->ZZds.ZZtakes.next2;
    if(ret==tail2)nxt2=tail2=NULL; 
    else nxt2=ret->ZZds.ZZtakes.next2;
    return ret;
}

PTR(Takes) const takes_2XtoXIterator::next2(){
    PTR(Takes) r;

    r=nxt2;
    if(r==tail2)nxt2=tail2=NULL; else nxt2=r->ZZds.ZZtakes.next2;
    return r;
}
