
// -------- data structure DOUBLY LINKED RING ---------------
// EQUIVALENT OF:
// template <class Node> class takes_Ring2
// ----------------------------------------------------------
// Ring2 could be derived from Ring2 through inheritance, but
//  (a) The complex functions (sort, remove, merge) are different anyway,
//  (b) we want to minimize the number of classes which will be code generated.
// For these two reasons, Ring2 is coded as a base class.
// ----------------------------------------------------------
#ifndef ZZ_takes_RING2_INCLUDED
#define ZZ_takes_RING2_INCLUDED

#include "environ.h"
#include PPF_PATH

class Takes;
typedef int (*takes_sortFun)(const PTR(Takes), const PTR(Takes));

// ----------------------------------------------------------
// description of the cooperating classes
// ----------------------------------------------------------
class takes_Ring2Element {
public:
    PTR(Takes) next;
    PTR(Takes) prev;
    takes_Ring2Element(){ next=prev=NULL; }
};

class takes_Ring2 {

    static int debugFun(PTR(Takes) tail);
public:
    // standard interface
    static PTR(Takes) addHead(PTR(Takes) tail, PTR(Takes) c); // returns new tail
    static PTR(Takes) addTail(PTR(Takes) tail, PTR(Takes) c); // returns new tail
    static PTR(Takes) append(PTR(Takes) tail,PTR(Takes) c1, PTR(Takes) c2); // returns new tail
    static void insert(PTR(Takes) c1, PTR(Takes) c2); // insert c1 before c2
    static PTR(Takes) remove(PTR(Takes) tail, PTR(Takes) c);  // returns new tail, NULL when empty
    static PTR(Takes) const next(PTR(Takes) p, PTR(Takes) c); // returns NULL when p is the tail
    static PTR(Takes) const prev(PTR(Takes) p, PTR(Takes) c); // returns NULL when p is the head
    static PTR(Takes) const nextRing(PTR(Takes) c); // next in the ring
    static PTR(Takes) const prevRing(PTR(Takes) c); // previous in the ring
    static PTR(Takes) sort(takes_sortFun cmpFun, PTR(Takes) tail); // returns the new tail
    static void merge(PTR(Takes) s,PTR(Takes) t);

    // historical DOL compatible interface
    static PTR(Takes) del(PTR(Takes) tail, PTR(Takes) c) { return remove(tail,c); }
    static PTR(Takes) add(PTR(Takes) tail, PTR(Takes) c) { return addHead(tail,c); }
    static void ins(PTR(Takes) c1, PTR(Takes) c2) { insert(c1,c2); }
    static PTR(Takes) const fwd(PTR(Takes) c){return nextRing(c);}
    static PTR(Takes) const bwd(PTR(Takes) c){return prevRing(c);}
    
};

class takes_Ring2Iterator {
    PTR(Takes) tail; // NULL when loop finished
    PTR(Takes) nxt;  // NULL when starting a new loop
    int dir;  // 0=from head, 1=from tail
public:
    // standard interface:          for(p=it.fromHead(x); p; p=it.next()){...}
    //                              for(p=it.fromTail(x); p; p=it.next()){...}
    takes_Ring2Iterator(){tail=nxt=NULL; dir=0;}
    PTR(Takes) fromHead(PTR(Takes) p);
    virtual PTR(Takes) fromTail(PTR(Takes) p);
    virtual PTR(Takes) const next();

    // historical DOL interface:    it.start(x); for(p= ++it; p; p= ++it){...}
    //                              it.start(x); for(p= --it; p; p= --it){...}
    void start(PTR(Takes) p);
    PTR(Takes) const operator++();
    PTR(Takes) const operator--();
    takes_Ring2Iterator(PTR(Takes) p){start(p);}
};
    
#endif // ZZ_takes_RING2_INCLUDED
