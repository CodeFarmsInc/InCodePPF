
// -------- data structure SINGLY LINKED LIST ---------------
// EQUIVALENT OF:
// template <class Parent,class Child> class courses_LinkedList
// ----------------------------------------------------------
#ifndef ZZ_courses_LINKED_LIST1_INCLUDED
#define ZZ_courses_LINKED_LIST1_INCLUDED

class Faculty;
class Course;

// ----------------------------------------------------------
// description of the cooperating classes
// ----------------------------------------------------------
class courses_LinkedList1Parent {
public:
    PTR(Course) tail;
    courses_LinkedList1Parent(){ tail=NULL; }
};

class courses_LinkedList1Child : public courses_Ring1Element {
public:
    courses_LinkedList1Child() : courses_Ring1Element(){ }
};

// the following class is used when Parent==Child
class courses_LinkedList1ParentLinkedList1Child : public courses_Ring1Element {
public:
    PTR(Course) tail;
    courses_LinkedList1ParentLinkedList1Child() : courses_Ring1Element(){ tail=NULL; }
};
// ----------------------------------------------------------

class courses_LinkedList1 : courses_Ring1 {

public:
    static PTR(Course) tail(PTR(Faculty) p);
    static PTR(Course) head(PTR(Faculty) p);
    static void addHead(PTR(Faculty) p, PTR(Course) c);
    static void addTail(PTR(Faculty) p, PTR(Course) c);
    static void append(PTR(Faculty) p,PTR(Course) c1, PTR(Course) c2);
    static void remove(PTR(Faculty) p, PTR(Course) c);
    static PTR(Course) const next(PTR(Faculty) p,PTR(Course) c);
    static PTR(Course) const nextRing(PTR(Course) c);
    static void sort(courses_sortFun cmpFun, PTR(Faculty) p);
    static void merge(PTR(Course) s,PTR(Course) t,PTR(Faculty) p);
    static void setTail(PTR(Faculty) p,PTR(Course) c,int check);

    // historical DOL compatible interface
    static void del(PTR(Faculty) p, PTR(Course) c){ remove(p,c);}
    static void add(PTR(Faculty) p, PTR(Course) c){ addHead(p,c);}
    static PTR(Course) child(PTR(Faculty) p);
    static void set(PTR(Faculty) p,PTR(Course) c){ setTail(p,c,0);}
    static PTR(Course) const fwd(PTR(Course) c){ return nextRing(c);}
};

class courses_LinkedList1Iterator : public courses_Ring1Iterator {
public:
    courses_LinkedList1Iterator() : courses_Ring1Iterator(){}
    courses_LinkedList1Iterator(const PTR(Faculty) p) : courses_Ring1Iterator(){start(p);}
    void start(const PTR(Faculty) p);
    PTR(Course) fromHead(PTR(Faculty) p);
};
    
#endif // ZZ_courses_LINKED_LIST1_INCLUDED
