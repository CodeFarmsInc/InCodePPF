

// -------- data structure SINGLY LINKED RING ---------------
// EQUIVALENT OF:
// template <class Node> class courses_Ring1
// ----------------------------------------------------------
#ifndef ZZ_courses_RING1_INCLUDED
#define ZZ_courses_RING1_INCLUDED

#include "environ.h"
#include PPF_PATH

class Course;
typedef int (*courses_sortFun)(const PTR(Course), const PTR(Course));

// ----------------------------------------------------------
// description of the cooperating classes
// ----------------------------------------------------------
class courses_Ring1Element {
public:
    PTR(Course) next;
    courses_Ring1Element(){ next=NULL; }
};

class courses_Ring1 {

public:
    // standard interface
    static PTR(Course) addHead(PTR(Course) tail, PTR(Course) c); // returns new tail
    static PTR(Course) addTail(PTR(Course) tail, PTR(Course) c); // returns new tail
    static PTR(Course) append(PTR(Course) tail,PTR(Course) c1, PTR(Course) c2); // returns new tail
    static PTR(Course) remove(PTR(Course) tail, PTR(Course) c);  // returns new tail, NULL when empty
    static PTR(Course) const next(PTR(Course) p, PTR(Course) c); // returns NULL when p is tail
    static PTR(Course) const nextRing(PTR(Course) c); // unprotected raw ring pointer
    static PTR(Course) sort(courses_sortFun cmpFun, PTR(Course) tail); // returns the new tail
    static void merge(PTR(Course) s,PTR(Course) t);

    // historical DOL compatible interface
    static PTR(Course) del(PTR(Course) tail, PTR(Course) c) { return remove(tail,c); }
    static PTR(Course) add(PTR(Course) tail, PTR(Course) c) { return addHead(tail,c); }
    static PTR(Course) const fwd(PTR(Course) c){ return nextRing(c);}
};

class courses_Ring1Iterator {
    PTR(Course) tail; // NULL when loop finished
    PTR(Course) nxt;  // NULL when starting a new loop
public:
    // standard interface:          for(p=it.fromHead(x); p; p=it.next()){...}
    courses_Ring1Iterator(){tail=nxt=NULL;}
    PTR(Course) fromHead(PTR(Course) p);
    PTR(Course) const next();

    // historical DOL interface:    it.start(x); for(p= ++it; p; p= ++it){...}
    void start(PTR(Course) p);
    PTR(Course) const operator++();
    courses_Ring1Iterator(Course *p){start(p);}
};
    
#endif // ZZ_courses_RING1_INCLUDED
