

// -------- data structure SINGLY LINKED RING ---------------
// EQUIVALENT OF:
// template <class Node> class students_Ring1
// ----------------------------------------------------------
#ifndef ZZ_students_RING1_INCLUDED
#define ZZ_students_RING1_INCLUDED

#include "environ.h"
#include PPF_PATH

class Student;
typedef int (*students_sortFun)(const PTR(Student), const PTR(Student));

// ----------------------------------------------------------
// description of the cooperating classes
// ----------------------------------------------------------
class students_Ring1Element {
public:
    PTR(Student) next;
    students_Ring1Element(){ next=NULL; }
};

class students_Ring1 {

public:
    // standard interface
    static PTR(Student) addHead(PTR(Student) tail, PTR(Student) c); // returns new tail
    static PTR(Student) addTail(PTR(Student) tail, PTR(Student) c); // returns new tail
    static PTR(Student) append(PTR(Student) tail,PTR(Student) c1, PTR(Student) c2); // returns new tail
    static PTR(Student) remove(PTR(Student) tail, PTR(Student) c);  // returns new tail, NULL when empty
    static PTR(Student) const next(PTR(Student) p, PTR(Student) c); // returns NULL when p is tail
    static PTR(Student) const nextRing(PTR(Student) c); // unprotected raw ring pointer
    static PTR(Student) sort(students_sortFun cmpFun, PTR(Student) tail); // returns the new tail
    static void merge(PTR(Student) s,PTR(Student) t);

    // historical DOL compatible interface
    static PTR(Student) del(PTR(Student) tail, PTR(Student) c) { return remove(tail,c); }
    static PTR(Student) add(PTR(Student) tail, PTR(Student) c) { return addHead(tail,c); }
    static PTR(Student) const fwd(PTR(Student) c){ return nextRing(c);}
};

class students_Ring1Iterator {
    PTR(Student) tail; // NULL when loop finished
    PTR(Student) nxt;  // NULL when starting a new loop
public:
    // standard interface:          for(p=it.fromHead(x); p; p=it.next()){...}
    students_Ring1Iterator(){tail=nxt=NULL;}
    PTR(Student) fromHead(PTR(Student) p);
    PTR(Student) const next();

    // historical DOL interface:    it.start(x); for(p= ++it; p; p= ++it){...}
    void start(PTR(Student) p);
    PTR(Student) const operator++();
    students_Ring1Iterator(Student *p){start(p);}
};
    
#endif // ZZ_students_RING1_INCLUDED
