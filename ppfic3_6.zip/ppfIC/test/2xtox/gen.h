#ifndef ZZ_CODEGEN_INCLUDE
#define ZZ_CODEGEN_INCLUDE


#define PPF_PATH "..\..\ppf\factory.h"
#include "..\..\lib\general.h"

class Faculty;
class Student;
class Course;
class Takes;

#include "tmp/students.h"
#include "tmp/students1.h"
#include "tmp/courses.h"
#include "tmp/courses1.h"
#include "tmp/takes.h"
#include "tmp/takes1.h"
#include "tmp/takes2.h"
#include "tmp/takes3.h"
#include "tmp/takes4.h"

// -----------------------------------------------
typedef class students_LinkedList1 students;
typedef class courses_LinkedList1 courses;
typedef class takes_2XtoX takes;
// -----------------------------------------------


class ZZ_Faculty {
public:
    students_LinkedList1Parent ZZstudents;
    courses_LinkedList1Parent ZZcourses;
};

class ZZ_Student {
public:
    students_LinkedList1Child ZZstudents;
    takes_2XtoXEntity1 ZZtakes;
};

class ZZ_Course {
public:
    courses_LinkedList1Child ZZcourses;
    takes_2XtoXEntity2 ZZtakes;
};

class ZZ_Takes {
public:
    takes_2XtoXRelation ZZtakes;
};

typedef students_LinkedList1Iterator students_Iterator;
typedef courses_LinkedList1Iterator courses_Iterator;
typedef takes_2XtoXIterator takes_Iterator;

#endif // ZZ_CODEGEN_INCLUDE
