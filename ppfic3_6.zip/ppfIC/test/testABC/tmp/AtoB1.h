
// -------- data structure DOUBLY LINKED LIST ---------------
// EQUIVALENT OF:
// template <class Parent,class Child> class AtoB_LinkedList
// ----------------------------------------------------------
#ifndef ZZ_AtoB_LINKED_LIST2_INCLUDED
#define ZZ_AtoB_LINKED_LIST2_INCLUDED

class A;
class B;

// ----------------------------------------------------------
// description of the cooperating classes
// ----------------------------------------------------------
class AtoB_LinkedList2Parent {
public:
    PTR(B) tail;
    AtoB_LinkedList2Parent(){ tail=NULL; }
};

class AtoB_LinkedList2Child : public AtoB_Ring2Element {
public:
    AtoB_LinkedList2Child() : AtoB_Ring2Element(){ }
};

// the following class is used when Parent==Child
class AtoB_LinkedList2ParentLinkedList2Child : public AtoB_Ring2Element {
public:
    PTR(B) tail;
    AtoB_LinkedList2ParentLinkedList2Child() : AtoB_Ring2Element(){ tail=NULL; }
};
// ----------------------------------------------------------

class AtoB_LinkedList2 : AtoB_Ring2 {

public:
    static PTR(B) const tail(PTR(A) p);
    static PTR(B) const head(PTR(A) p);
    static void addHead(PTR(A) p, PTR(B) c);
    static void addTail(PTR(A) p, PTR(B) c);
    static void append(PTR(A) p,PTR(B) c1, PTR(B) c2);
    static void insert(PTR(B) c1, PTR(B) c2);
    static void remove(PTR(A) p, PTR(B) c);
    static PTR(B) const next(PTR(A) p, PTR(B) c);
    static PTR(B) const prev(PTR(A) p, PTR(B) c);
    static PTR(B) const nextRing(PTR(B) c);
    static PTR(B) const prevRing(PTR(B) c);
    static void sort(AtoB_sortFun cmpFun, PTR(A) p);
    static void merge(PTR(B) s,PTR(B) t,PTR(A) p);
    static void setTail(PTR(A) p,PTR(B) c,int check);

    // historical DOL compatible interface
    static void del(PTR(A) p, PTR(B) c) { remove(p,c); }
    static void add(PTR(A) p, PTR(B) c) { addHead(p,c);}
    static void ins(PTR(B) c1, PTR(B) c2) { insert(c1,c2); }
    static PTR(B) child(PTR(A) p);
    static void set(PTR(A) p,PTR(B) c){ setTail(p,c,0);}
    static PTR(B) const fwd(PTR(B) c){return nextRing(c);}
    static PTR(B) const bwd(PTR(B) c){return prevRing(c);}
};

class AtoB_LinkedList2Iterator : public AtoB_Ring2Iterator {
public:
    AtoB_LinkedList2Iterator() : AtoB_Ring2Iterator(){}
    AtoB_LinkedList2Iterator(const PTR(A) p) : AtoB_Ring2Iterator(){ start(p); }
    void start(const PTR(A) p);
    PTR(B) fromHead(PTR(A) p);
    PTR(B) fromTail(PTR(A) p);
};
    
#endif // ZZ_AtoB_LINKED_LIST2_INCLUDED
