#define PPF_LIGHT
#include "c:\ppf\factory.h"
